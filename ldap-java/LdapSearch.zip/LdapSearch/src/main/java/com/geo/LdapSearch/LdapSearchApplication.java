package com.geo.LdapSearch;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LdapSearchApplication {

	public static void main(String[] args) {
		SpringApplication.run(LdapSearchApplication.class, args);
	}

}
