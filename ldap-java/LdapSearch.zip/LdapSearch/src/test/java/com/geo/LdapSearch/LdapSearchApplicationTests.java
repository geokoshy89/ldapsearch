package com.geo.LdapSearch;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LdapSearchApplicationTests {

	@Test
	void contextLoads() {
	}

}
